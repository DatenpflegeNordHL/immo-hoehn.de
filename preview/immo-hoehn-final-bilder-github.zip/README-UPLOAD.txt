HÖHN IMMOBILIEN – FINALER BILD-UPLOAD
=====================================

Diese ZIP enthält nur die zuletzt ausgewählten / neu erzeugten Bildassets
mit den Dateinamen, die die Preview bereits erwartet.

Zielordner im Repository:
preview/assets/

Dateien:
- hero-coast.webp
- property-poetenitz.webp
- rosenhagen-beach.webp
- priwall-interior.webp
- region-map.webp
- heritage-house.webp

Wichtig:
- region-map.webp ist die NEUE zusammenhängende transparente Region-Illustration
  (Karte links + Dünengras rechts in EINEM Asset).
- heritage-house.webp besitzt echte Transparenz.
- hero-coast.webp ist das neue durchgehende Hero-Foto.
- Die drei Immobilienbilder sind die zuletzt erzeugten zusammenhängenden Fotovarianten.

Nach Upload auf GitHub bitte die Dateien im Branch
redesign/coastal-blueprint unter preview/assets/ ersetzen.

MANIFEST.json enthält Maße, Dateigrößen und SHA-256-Prüfsummen,
damit nach dem Upload geprüft werden kann, ob GitHub die Dateien vollständig
übernommen hat.
